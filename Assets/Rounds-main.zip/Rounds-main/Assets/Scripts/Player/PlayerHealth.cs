public class PlayerHealth : CharacterHealth
{
}

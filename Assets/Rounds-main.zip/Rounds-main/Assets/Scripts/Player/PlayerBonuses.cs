public class PlayerBonuses : CharacterBonuses
{
}

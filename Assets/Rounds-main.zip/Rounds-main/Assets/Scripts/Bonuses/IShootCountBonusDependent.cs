﻿// Определяем интерфейс IShootCountBonusDependent 
public interface IShootCountBonusDependent
{
  void SetShootCount(int value); // Задаём пустой метод SetShootCount()
}
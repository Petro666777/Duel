﻿// Определяем интерфейс IHitTypeBonusDependent 
public interface IHitTypeBonusDependent
{
  void SetHit(BulletHit hit); // Задаём пустой метод SetHit()
}
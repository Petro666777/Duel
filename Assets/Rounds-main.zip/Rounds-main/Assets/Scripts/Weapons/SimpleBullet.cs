using UnityEngine;

public class SimpleBullet : Bullet
{
}

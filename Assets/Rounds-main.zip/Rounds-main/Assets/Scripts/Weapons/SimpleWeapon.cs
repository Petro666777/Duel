public class SimpleWeapon : Weapon
{
}

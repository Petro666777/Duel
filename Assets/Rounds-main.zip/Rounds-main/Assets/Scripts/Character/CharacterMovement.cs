public abstract class CharacterMovement : CharacterPart
{
}
